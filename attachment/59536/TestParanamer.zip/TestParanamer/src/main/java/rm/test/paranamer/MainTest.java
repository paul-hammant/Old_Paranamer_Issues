package rm.test.paranamer;

import java.lang.reflect.Method;

import com.thoughtworks.paranamer.AdaptiveParanamer;
import com.thoughtworks.paranamer.Paranamer;

public class MainTest
{
    public static void main(String[] args)
    {
        System.out.println("Test paranamer...");

        displayParameters(AnInterfaceOk.class);
        displayParameters(AnInterfaceNotOk.class);
    }

    private static void displayParameters(final Class clazz)
    {
        try
        {
            System.out.println("\n---------------\n" + clazz);

            for (Method m : clazz.getDeclaredMethods())
            {
                System.out.println(" -> Parameter names for method : " + m.getName());

                Paranamer paranamer = new AdaptiveParanamer();

                String[] parameterNames = paranamer.lookupParameterNames(m);

                for (String paramName : parameterNames)
                {
                    System.out.println("      - " + paramName);
                }
            }
        } catch (Exception ex)
        {
            System.err.println("\n\n /!\\ Error during list parameters /!\\ \n\n");

            ex.printStackTrace();
        }
    }
}
