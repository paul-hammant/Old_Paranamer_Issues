package rm.test.paranamer;

public interface AnInterfaceOk
{
    boolean doSomethingOk(long param1, String param2, Object param3);
}
