package rm.test.paranamer;

public interface AnInterfaceNotOk
{
    boolean doSomethingNotOk(long[] param);
}
